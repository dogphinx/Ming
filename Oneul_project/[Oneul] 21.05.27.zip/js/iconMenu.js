const iconMenuWindow = document.querySelector('.icon_menu_gnb'),
    iconMenuLi = document.querySelector('.icon_menu_gnb').children[2].children[0].children;

// console.log(iconMenuLi);

const iconMenuClose = () => {
    iconMenuWindow.classList.remove("icon_menu_on")
}

const iconMenuOpen = () => {
    iconMenuWindow.classList.add("icon_menu_on")
}

iconMenu.addEventListener("click", iconMenuOpen);
iconMenuWindow.children[0].children[0].addEventListener("click", iconMenuClose);
iconMenuWindow.children[1].addEventListener("click", iconMenuClose);
for (let i = 0; i < 5; i++) {
    iconMenuLi[i].addEventListener("click", iconMenuClose);
}
// iconMenuLi[5] 는 꺼지지 않고 예약창만 뜨게 해야함.