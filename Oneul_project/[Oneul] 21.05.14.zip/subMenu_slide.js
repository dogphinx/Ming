let gnb = document.querySelector("#gnb");
let gnbMenu = gnb.children[0].children[1];
let gnbRoom = gnb.children[0].children[3];
let content = document.querySelector("#content");
// let mainImgSlide = document.querySelector("#main_img_slide");
let slideCaption = document.getElementsByClassName("slide-caption");


function slideUp() {
    subMenu.style.transition = "all 0.3s ease-in-out";
    subMenu.style.height = "0px"; 
}

function slideDown() {
    subMenu.style.transition = "all 0.3s ease-in-out";
    subMenu.style.height = "250px";
}

function subMenuMouseOver(event) {
    slideDown();
}

function subMenuMouseOut(event) {
    slideUp();
    // console.log("마우스 아웃");
}



gnbMenu.addEventListener("mouseover", subMenuMouseOver);
// gnbMenu.addEventListener("mouseout", subMenuMouseOut);
gnbRoom.addEventListener("mouseover", subMenuMouseOver);
// gnbRoom.addEventListener("mouseout", subMenuMouseOut);
content.addEventListener("mouseover", subMenuMouseOut);
slideCaption[0].addEventListener("mouseover", subMenuMouseOut);
slideCaption[1].addEventListener("mouseover", subMenuMouseOut);
slideCaption[2].addEventListener("mouseover", subMenuMouseOut);
slideCaption[3].addEventListener("mouseover", subMenuMouseOut);
slideCaption[4].addEventListener("mouseover", subMenuMouseOut);
slideCaption[5].addEventListener("mouseover", subMenuMouseOut);


// 메뉴랑 룸이 호버된동안 서브메뉴가 보여야하고.
// 서브 메뉴창에 마우스를 오버하면 서브메뉴창과 메뉴호버 유지. 

// active + fade 로 구성
// 1. 메뉴 호버 active
// 2. 메뉴 룸 호버 active
// 3. 서브메뉴 호버 active 
// 4. 서브메뉴 마우스아웃 fade 헤더 호버 

// MainMenuActive class
// 헤더 마우스오버, 서브메뉴 마우스 오버 
// 헤더 마우스 아웃(이거부터 하고 서브메뉴 마우스오버 처리되게). 서브메뉴 마우스 아웃(서브메뉴 슬라이드 업 된 후 실행)
// SubMenuActive class
