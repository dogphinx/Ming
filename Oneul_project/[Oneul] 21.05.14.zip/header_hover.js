let header = document.querySelector("header");
let logo = document.getElementById("logo").children[0].children[0];
let iconMenu = document.getElementById("icon_menu").children[0];
let subMenu = document.getElementById("sub_gnb");
let subMenuUl1 = subMenu.children[0];
let subMenuUl2 = subMenu.children[1];

function headerMouseOver(event) {
    logo.src = "./img/logo.png";
    iconMenu.src = "./img/icon_menu.png"
}

function headerMouseOut(event) {
    logo.src = "./img/logo_on.png";
    iconMenu.src = "./img/icon_menu_main.png"
}

header.addEventListener("mouseover", headerMouseOver);
header.addEventListener("mouseout", headerMouseOut);


