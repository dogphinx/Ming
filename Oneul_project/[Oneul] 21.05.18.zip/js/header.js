let header = document.querySelector("header"),
    logo = document.getElementById("logo").children[0].children[0],
    iconMenu = document.getElementById("icon_menu").children[0];



// 헤더 호버시 사진 변경
function headerMouseOver(event) {
    logo.src = "./img/logo.png";
    iconMenu.src = "./img/icon_menu.png"
}

function headerMouseOut(event) {
    logo.src = "./img/logo_on.png";
    iconMenu.src = "./img/icon_menu_main.png"
    // 아래는 헤더 마우스 아웃시 
    header.style.height = '125px';
    header.style.backgroundColor = 'transparent';
}

header.addEventListener("mouseover", headerMouseOver);
header.addEventListener("mouseout", headerMouseOut);



// 메뉴 호버시 서브메뉴 슬라이드다운.
let mainGnbLi2 = document.getElementById("gnb").children[0].children[1],
    mainGnbLi4 = document.getElementById("gnb").children[0].children[3];

// 2번째 gnb li와 4번째 gnb li에 마우스를 올리면 header 높이가 350px 로 변경. 나가면 header의 높이를 125px 로 변경

mainGnbLi2.addEventListener('mouseover', function(){
    header.style.height = '350px';
})
mainGnbLi4.addEventListener('mouseover', function(){
    header.style.height = '350px';
})
header.addEventListener('mouseover', function(){
    header.style.backgroundColor = 'white';
})




// 헤더 125px~350px 헤더부분 마우스오버시 를 쓸 수 없음. 헤더높이를 125px로 불러옴.

// let headerHeight = header.getBoundingClientRect().bottom
// setInterval(function() {
//     console.log(headerHeight);
// }, 1000)
