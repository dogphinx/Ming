let header = document.querySelector("header");
let logo = document.getElementById("logo").children[0].children[0];
let iconMenu = document.getElementById("icon_menu").children[0];

let mainMenuUl = document.getElementById("gnb").children[0];

// 헤더 호버시 사진 변경
function headerMouseOver(event) {
    logo.src = "./img/logo.png";
    iconMenu.src = "./img/icon_menu.png"
}

function headerMouseOut(event) {
    logo.src = "./img/logo_on.png";
    iconMenu.src = "./img/icon_menu_main.png"
}

// header.addEventListener("mouseover", headerMouseOver);
// header.addEventListener("mouseout", headerMouseOut);



// 메뉴 호버시 서브메뉴 슬라이드다운.



let getHeight = function (el) {
    var el_style = window.getComputedStyle(el),
        el_display = el_style.display,
        el_position = el_style.position,
        el_visibility = el_style.visibility,
        el_max_height = el_style.maxHeight.replace('px', '').replace('%', ''),

        wanted_height = 0;

    // window.getComputedStyle() : 인자로 전달받은 요소의 모든 css 속성값을 담은 객체를 반환합니다.

    // if its not hidden we just return normal height
    // el_display 가 none 이 아니고 && el_max_height 가 0이 아닐때 offsetHeight(엘리먼트의 전체 크기)
    if (el_display !== 'none' && el_max_height !== '0') {
        return el.offsetHeight;
    }

    // the element is hidden so:
    // making the el block so we can meassure its height but still be hidden
    // 엘리먼트 블럭을 만든다. -> 그러면 그것의 높이를 측정할 수 있다. (여전히 숨겨져있지만)
    el.style.position = 'absolute';
    el.style.visibility = 'hidden';
    el.style.display = 'block';

    // 원하는 높이 = 엘리먼트의 전체크기
    wanted_height = el.offsetHeight;

    // reverting to the original values
    // 원래 값으로 되돌리기
    el.style.display = el_display;
    el.style.position = el_position;
    el.style.visibility = el_visibility;

    return wanted_height;
}


/**
 * toggleSlide mimics the jQuery version of slideDown and slideUp
 * all in one function comparing the max-heigth to 0
 */
let toggleSlide = function (el) {
    let el_max_height = 0;

    if (el.getAttribute('data-max-height')) {
        // we've already used this before, so everything is setup
        if (el.style.maxHeight.replace('px', '').replace('%', '') === '0') {
            el.style.maxHeight = el.getAttribute('data-max-height');
        } else {
            el.style.maxHeight = '0';
        }
    } else {
        el_max_height = getHeight(el) + 'px';
        el.style['transition'] = 'max-height 0.5s ease-in-out';
        el.style.overflowY = 'hidden';
        el.style.maxHeight = '0';
        el.setAttribute('data-max-height', el_max_height);
        el.style.display = 'block';

        // we use setTimeout to modify maxHeight later than display (to we have the transition effect)
        setTimeout(function () {
            el.style.maxHeight = el_max_height;
        }, 10);
    }
};

// 헤더영역 마우스 아웃 원래대로
// Menu Room 호버 -> 